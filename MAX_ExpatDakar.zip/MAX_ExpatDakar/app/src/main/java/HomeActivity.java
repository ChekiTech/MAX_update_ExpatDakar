package net.chekitech.expatdakar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.os.Handler;
import android.widget.ImageView;

public class HomeActivity extends AppCompatActivity {

    private Handler mHandler;
    private Runnable mRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        ImageView buttk= (ImageView) findViewById(R.id.splashimage);

        buttk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intk= new Intent(HomeActivity.this,WelcomeActivity.class);
                startActivity(intk);
            }
        });

        mRunnable = new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(getApplicationContext(),WelcomeActivity.class));
            }
        };

        mHandler = new Handler();

        mHandler.postDelayed(mRunnable,1000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mHandler!=null && mRunnable!=null)
            mHandler.removeCallbacks(mRunnable);
    }
    @Override
    public void onBackPressed() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
        System.exit(0);
        super.onBackPressed();
    }
}
